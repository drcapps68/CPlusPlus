#include <iostream>

using namespace std;

void Answer3();

int main() {

    Answer3();

    system("pause");
    return 0;
}

void Answer3()
{
    int a[6] = {10,20,30};
    int * ptr = &a[2];
    for (int i = 0; i > -4; i--) {
        cout << *(ptr+i) + i << " ";
    }
}